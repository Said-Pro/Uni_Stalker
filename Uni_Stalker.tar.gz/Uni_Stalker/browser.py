#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
Browser module for UnionStalker plugin
Handles network connectivity checks and connections
"""

import socket
import time
import subprocess
import logging
import requests
import os
import sys
from urllib.parse import urlparse

# Configure logging
logger = logging.getLogger(__name__)

class Browser:
    """Browser class for handling network connections"""
    
    def __init__(self):
        """Initialize the browser with default settings"""
        self.connection = None
        self.timeout = 5
        self.last_request_time = 0
        self.user_agent = "Mozilla/5.0 Stalker Middleware"
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": self.user_agent})
        
        logger.info("Browser initialized")

    def check_network_connectivity(self):
        """Check connectivity to Google and local server"""
        try:
            # Check connection to Google
            google_response = self.session.get("https://www.google.com", timeout=3)
            google_status = google_response.status_code == 200
            
            # Check connection to local server
            local_status = self.ping_host("127.0.0.1")
            
            logger.info(f"Network connectivity check: Google={google_status}, Local={local_status}")
            
            return {
                "internet": google_status,
                "local": local_status
            }
        except requests.exceptions.RequestException as e:
            logger.error(f"Network connectivity check failed: {str(e)}")
            return {
                "internet": False,
                "local": self.ping_host("127.0.0.1")
            }

    def connect_to_server(self, host, port, timeout=5):
        """Connect to a specific server"""
        try:
            if self.connection:
                self.disconnect()
                
            logger.info(f"Connecting to {host}:{port}")
            
            parsed_url = urlparse(host)
            if parsed_url.netloc:
                hostname = parsed_url.netloc
            else:
                hostname = parsed_url.path.split('/')[0]
                
            if ':' in hostname:
                hostname = hostname.split(':')[0]
                
            self.connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.connection.settimeout(timeout)
            self.connection.connect((hostname, port))
            
            logger.info(f"Successfully connected to {hostname}:{port}")
            return True
            
        except socket.error as e:
            logger.error(f"Socket error connecting to {host}:{port}: {str(e)}")
            self.connection = None
            return False
            
        except Exception as e:
            logger.error(f"Error connecting to {host}:{port}: {str(e)}")
            self.connection = None
            return False

    def disconnect(self):
        """Disconnect from the current server"""
        if self.connection:
            try:
                logger.info("Disconnecting from server")
                self.connection.close()
            except Exception as e:
                logger.error(f"Error disconnecting: {str(e)}")
            finally:
                self.connection = None

    def send_request(self, data):
        """Send data to the connected server"""
        if not self.connection:
            logger.error("Cannot send request: not connected")
            return None
            
        try:
            # Throttle requests
            current_time = time.time()
            if current_time - self.last_request_time < 1:  # Minimum 1 second between requests
                time.sleep(1 - (current_time - self.last_request_time))
                
            logger.debug(f"Sending data: {data}")
            
            self.connection.send(data.encode('utf-8'))
            self.last_request_time = time.time()
            
            # Receive response
            response = b""
            self.connection.settimeout(self.timeout)
            
            while True:
                chunk = self.connection.recv(4096)
                if not chunk:
                    break
                response += chunk
                
            logger.debug(f"Received response: {response[:100]}...")
            return response.decode('utf-8')
            
        except socket.timeout:
            logger.error("Socket timeout while sending request")
            return None
            
        except socket.error as e:
            logger.error(f"Socket error while sending request: {str(e)}")
            self.disconnect()
            return None
            
        except Exception as e:
            logger.error(f"Error sending request: {str(e)}")
            return None

    def ping_host(self, host, timeout=2):
        """Ping a host to check if it's reachable"""
        try:
            logger.debug(f"Pinging host: {host}")
            
            # Parse host from URL if needed
            parsed_url = urlparse(host)
            if parsed_url.netloc:
                hostname = parsed_url.netloc
            else:
                hostname = parsed_url.path.split('/')[0]
                
            if ':' in hostname:
                hostname = hostname.split(':')[0]
                
            # Try to connect to check if host is reachable
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            
            # Resolve hostname to IP address
            try:
                ip = socket.gethostbyname(hostname)
            except socket.gaierror:
                logger.error(f"Could not resolve hostname: {hostname}")
                return False
                
            # Try to connect to port 80 (default HTTP)
            result = s.connect_ex((ip, 80))
            s.close()
            
            if result == 0:
                logger.info(f"Host {hostname} is reachable")
                return True
            else:
                logger.warning(f"Host {hostname} is not reachable")
                return False
                
        except Exception as e:
            logger.error(f"Error pinging host {host}: {str(e)}")
            return False