# -*- coding: utf-8 -*-
import os
import json
import requests
import logging
import re
from collections import Counter
from Screens.Screen import Screen
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.ServiceEventTracker import ServiceEventTracker
from Components.Sources.StaticText import StaticText
from enigma import eServiceReference, iPlayableService, eTimer
from Screens.InfoBarGenerics import InfoBarShowHide, InfoBarSeek, InfoBarNotifications

# Setup logging
logging.basicConfig(level=logging.DEBUG, filename='/tmp/stalker_manager.log', filemode='a',
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
PLUGIN_PATH = os.path.dirname(os.path.abspath(__file__))
FAVORITES_PATH = os.path.join(PLUGIN_PATH, "favorites.json")


class StalkerPlayer(Screen, InfoBarShowHide, InfoBarSeek, InfoBarNotifications):
    """Lecteur intégré avec fonctionnalités de zapping pour les chaînes Stalker."""
    
    skin = """
        <screen position="center,center" size="1280,720" title="Stalker Player" backgroundColor="#8b008b" flags="wfNoBorder">
            <!-- Info Bar (masquable) -->
            <widget name="channel_info" position="50,50" size="600,100" font="Regular;24" backgroundColor="#80000000" foregroundColor="white" transparent="1" />
            <widget name="current_channel" position="50,160" size="400,40" font="Bold;28" backgroundColor="#80000000" foregroundColor="yellow" transparent="1" />
            <widget name="channel_number" position="50,200" size="100,40" font="Bold;32" backgroundColor="#80000000" foregroundColor="green" transparent="1" />
            
            <!-- Contrôles (affichés temporairement) -->
            <widget name="controls_info" position="50,620" size="1180,80" font="Regular;20" backgroundColor="#80000000" foregroundColor="white" transparent="1" />
            
            <!-- Liste des chaînes (masquable avec bouton LIST) -->
            <widget name="channel_list" position="900,100" size="350,500" itemHeight="35" font="Regular;22" backgroundColor="#80000000" transparent="1" scrollbarMode="showOnDemand" />
        </screen>
    """

    def __init__(self, session, server, channels, current_index=0):
        """
        Initialise le lecteur avec la liste des chaînes
        
        Args:
            session: Session Enigma2
            server: Configuration du serveur Stalker
            channels: Liste des chaînes [(nom, données_chaîne), ...]
            current_index: Index de la chaîne actuelle
        """
        Screen.__init__(self, session)
        InfoBarShowHide.__init__(self)
        InfoBarSeek.__init__(self)
        InfoBarNotifications.__init__(self)
        
        self.session = session
        self.server = server
        self.host = server["SERVER_HOST"].rstrip('/c')
        self.mac = server["ADRESS_MAC"]
        self.channels = channels
        self.current_index = current_index
        self.show_list = False
        self.favorites = self.load_favorites()
        
        # Widgets
        self["channel_info"] = Label("")
        self["current_channel"] = Label("")
        self["channel_number"] = Label("")
        self["controls_info"] = Label("")
        self["channel_list"] = MenuList([])
        
        # Timer pour masquer les infos
        self.hide_timer = eTimer()
        self.hide_timer.callback.append(self.hideInfo)
        
        # Actions map
        self["actions"] = ActionMap([
            "OkCancelActions", 
            "DirectionActions", 
            "NumberActions",
            "ColorActions",
            "InfobarActions",
            "InfobarSeekActions",
            "MoviePlayerActions"
        ], {
            # Navigation des chaînes
            "up": self.channelDown,
            "down": self.channelUp,
            "left": self.seekBackward,
            "right": self.seekForward,
            
            # Contrôles de lecture
            "ok": self.toggleInfo,
            "info": self.showChannelInfo,
            "playpause": self.playPause,
            
            # Navigation par numéros
            "1": self.keyNumber,
            "2": self.keyNumber,
            "3": self.keyNumber,
            "4": self.keyNumber,
            "5": self.keyNumber,
            "6": self.keyNumber,
            "7": self.keyNumber,
            "8": self.keyNumber,
            "9": self.keyNumber,
            "0": self.keyNumber,
            
            # Fonctions spéciales
            "red": self.addToFavorites,
            "green": self.showFavorites,
            "yellow": self.toggleChannelList,
            "blue": self.showChannelInfo,
            
            # Sortie
            "cancel": self.close,
            "exit": self.close,
            "stop": self.close
        }, -2)
        
        # Variables pour la saisie de numéros
        self.number_input = ""
        self.number_timer = eTimer()
        self.number_timer.callback.append(self.processNumberInput)
        
        # Service tracker pour surveiller les événements de lecture
        self.__event_tracker = ServiceEventTracker(screen=self, eventmap={
            iPlayableService.evStart: self.serviceStarted,
            iPlayableService.evEnd: self.serviceEnded,
            iPlayableService.evStopped: self.serviceStopped
        })
        
        # Préparer la liste des chaînes
        self.updateChannelList()
        
        # Commencer la lecture de la chaîne actuelle
        self.playCurrentChannel()
        
        # Afficher les contrôles initialement
        self.showControls()

    def updateChannelList(self):
        """Met à jour la liste des chaînes pour affichage."""
        channel_list = []
        for i, (name, channel) in enumerate(self.channels):
            prefix = "► " if i == self.current_index else "   "
            if channel['id'] in self.favorites:
                prefix += "★ "
            display_name = f"{i+1:3d}. {prefix}{name}"
            channel_list.append(display_name)
        
        self["channel_list"].setList(channel_list)
        
        # Positionner sur la chaîne actuelle
        if 0 <= self.current_index < len(self.channels):
            self["channel_list"].moveToIndex(self.current_index)

    def playCurrentChannel(self):
        """Lit la chaîne actuellement sélectionnée."""
        if not (0 <= self.current_index < len(self.channels)):
            return False
            
        name, channel = self.channels[self.current_index]
        channel_id = channel.get('id')
        
        if not channel_id:
            self.showMessage(f"Erreur: ID manquant pour {name}")
            return False
        
        try:
            # Construction de l'URL de stream
            stream_url = f"{self.host}/live/{self.mac}/{channel_id}.ts?mac={self.mac}"
            
            logging.info(f"Playing channel {self.current_index + 1}: {name} - {stream_url}")
            
            # Créer et lancer le service
            service_ref = eServiceReference(4097, 0, stream_url)
            service_ref.setName(name)
            
            # Arrêter le service précédent et lancer le nouveau
            self.session.nav.stopService()
            result = self.session.nav.playService(service_ref)
            
            # Mettre à jour l'affichage
            self.updateChannelInfo(name, self.current_index + 1)
            self.updateChannelList()
            
            if result:
                logging.info(f"Successfully started playback for {name}")
                return True
            else:
                logging.error(f"Failed to start playback for {name}")
                self.showMessage(f"Erreur de lecture: {name}")
                return False
                
        except Exception as e:
            logging.error(f"Error playing channel {name}: {str(e)}", exc_info=True)
            self.showMessage(f"Erreur: {str(e)}")
            return False

    def updateChannelInfo(self, name, number):
        """Met à jour l'affichage des informations de la chaîne."""
        self["current_channel"].setText(name)
        self["channel_number"].setText(str(number))
        
        # Afficher des infos supplémentaires si disponibles
        if 0 <= self.current_index < len(self.channels):
            channel = self.channels[self.current_index][1]
            info_text = f"Chaîne {number}: {name}"
            if channel.get('description'):
                info_text += f"\n{channel['description']}"
            self["channel_info"].setText(info_text)

    def channelUp(self):
        """Passe à la chaîne suivante."""
        if self.current_index < len(self.channels) - 1:
            self.current_index += 1
        else:
            self.current_index = 0  # Boucle vers la première chaîne
        
        self.playCurrentChannel()
        self.showControls()

    def channelDown(self):
        """Passe à la chaîne précédente."""
        if self.current_index > 0:
            self.current_index -= 1
        else:
            self.current_index = len(self.channels) - 1  # Boucle vers la dernière chaîne
        
        self.playCurrentChannel()
        self.showControls()

    def keyNumber(self, key):
        """Gère la saisie de numéros pour aller à une chaîne spécifique."""
        number = str(key)
        self.number_input += number
        
        # Afficher le numéro en cours de saisie
        self["channel_number"].setText(self.number_input)
        self.showControls()
        
        # Démarrer/redémarrer le timer
        self.number_timer.stop()
        self.number_timer.start(2000, True)  # 2 secondes de délai

    def processNumberInput(self):
        """Traite la saisie de numéro pour changer de chaîne."""
        if self.number_input:
            try:
                channel_num = int(self.number_input)
                if 1 <= channel_num <= len(self.channels):
                    self.current_index = channel_num - 1
                    self.playCurrentChannel()
                else:
                    self.showMessage(f"Chaîne {channel_num} n'existe pas")
            except ValueError:
                self.showMessage("Numéro de chaîne invalide")
            
            self.number_input = ""

    def toggleInfo(self):
        """Active/désactive l'affichage des informations."""
        if self.shown:
            self.hide()
        else:
            self.show()
            self.showControls()

    def showControls(self):
        """Affiche temporairement les contrôles et informations."""
        controls_text = "↑/↓: Chaînes | ←/→: Seek | OK: Info | Rouge: Favoris | Jaune: Liste | Sortie: Quitter"
        self["controls_info"].setText(controls_text)
        
        self.show()
        
        # Programmer le masquage automatique
        self.hide_timer.stop()
        self.hide_timer.start(5000, True)  # Masquer après 5 secondes

    def hideInfo(self):
        """Masque les informations (garde juste la vidéo)."""
        if not self.show_list:  # Ne pas masquer si la liste est affichée
            self.hide()

    def showChannelInfo(self):
        """Affiche les informations détaillées de la chaîne actuelle."""
        if 0 <= self.current_index < len(self.channels):
            name, channel = self.channels[self.current_index]
            info = f"Chaîne: {name}\n"
            info += f"Numéro: {self.current_index + 1}\n"
            if channel.get('description'):
                info += f"Description: {channel['description']}\n"
            if channel.get('genre_title'):
                info += f"Genre: {channel['genre_title']}\n"
            
            self.session.open(MessageBox, info, MessageBox.TYPE_INFO, timeout=10)

    def toggleChannelList(self):
        """Active/désactive l'affichage de la liste des chaînes."""
        self.show_list = not self.show_list
        if self.show_list:
            self["channel_list"].show()
            self.show()
        else:
            self["channel_list"].hide()

    def addToFavorites(self):
        """Ajoute/supprime la chaîne actuelle des favoris."""
        if 0 <= self.current_index < len(self.channels):
            channel = self.channels[self.current_index][1]
            channel_id = channel.get('id')
            name = self.channels[self.current_index][0]
            
            if channel_id in self.favorites:
                self.favorites.remove(channel_id)
                self.showMessage(f"{name} supprimée des favoris")
            else:
                self.favorites.append(channel_id)
                self.showMessage(f"{name} ajoutée aux favoris")
            
            self.save_favorites()
            self.updateChannelList()

    def showFavorites(self):
        """Filtre pour n'afficher que les chaînes favorites."""
        favorite_channels = []
        for i, (name, channel) in enumerate(self.channels):
            if channel['id'] in self.favorites:
                favorite_channels.append((name, channel))
        
        if favorite_channels:
            # Créer une nouvelle instance avec seulement les favoris
            self.session.open(StalkerPlayer, self.server, favorite_channels, 0)
        else:
            self.showMessage("Aucune chaîne favorite")

    def playPause(self):
        """Met en pause/reprend la lecture."""
        service = self.session.nav.getCurrentService()
        if service:
            pausable = service.pause()
            if pausable:
                pausable.pause()
                self.showMessage("Pause")

    def seekBackward(self):
        """Recule de 10 secondes (si supporté par le flux)."""
        self.doSeekRelative(-1, 10 * 90000)

    def seekForward(self):
        """Avance de 10 secondes (si supporté par le flux)."""
        self.doSeekRelative(1, 10 * 90000)

    def showMessage(self, message, timeout=3):
        """Affiche un message temporaire."""
        self["channel_info"].setText(message)
        # Programmer le retour aux infos normales
        self.hide_timer.stop()
        self.hide_timer.start(timeout * 1000, True)

    # Événements de service
    def serviceStarted(self):
        """Appelé quand un service démarre."""
        logging.debug("Service started")

    def serviceEnded(self):
        """Appelé quand un service se termine."""
        logging.debug("Service ended")

    def serviceStopped(self):
        """Appelé quand un service s'arrête."""
        logging.debug("Service stopped")

    def load_favorites(self):
        """Charge la liste des favoris depuis le fichier JSON."""
        try:
            if os.path.exists(FAVORITES_PATH):
                with open(FAVORITES_PATH, 'r') as f:
                    return json.load(f)
            return []
        except (json.JSONDecodeError, IOError) as e:
            logging.error(f"Error loading favorites: {str(e)}", exc_info=True)
            return []

    def save_favorites(self):
        """Sauvegarde la liste des favoris dans le fichier JSON."""
        try:
            with open(FAVORITES_PATH, 'w') as f:
                json.dump(self.favorites, f, indent=4)
        except IOError as e:
            logging.error(f"Error saving favorites: {str(e)}", exc_info=True)

    def close(self):
        """Ferme le lecteur et arrête la lecture."""
        self.hide_timer.stop()
        self.number_timer.stop()
        self.session.nav.stopService()
        Screen.close(self)


# Modification de la classe UStalker_Live_Categories pour intégrer le nouveau lecteur
class UStalker_Live_Categories(Screen):
    """Écran pour afficher et gérer les chaînes de télévision en direct via une API Stalker."""
    skin = """
        <screen position="center,center" size="1200,750" title="Live TV" backgroundColor="#8b008b">
            <widget name="main_list" position="50,120" size="1100,480" itemHeight="45" backgroundColor="#003161" transparent="1" scrollbarMode="showOnDemand" font="Regular;28"/>
            <eLabel text="Retour" position="410,660" size="200,40" font="Bold;30" halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <eLabel text="Recherche" position="210,660" size="200,40" font="Bold;30" halign="center" valign="center" backgroundColor="green" foregroundColor="white"/>
            <eLabel text="Favoris" position="610,660" size="200,40" font="Bold;30" halign="center" valign="center" backgroundColor="yellow" foregroundColor="white"/>
            <eLabel text="Lecteur" position="810,660" size="200,40" font="Bold;30" halign="center" valign="center" backgroundColor="blue" foregroundColor="white"/>
            <widget name="status" position="50,50" size="1100,40" font="Bold;30" halign="center" backgroundColor="#003161" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session, server, genre_id=None, bouquet_title=None):
        """Initialise l'écran avec les paramètres du serveur et un ID de genre optionnel."""
        Screen.__init__(self, session)
        self.session = session
        self.server = server
        self.host = server["SERVER_HOST"].rstrip('/c')
        self.mac = server["ADRESS_MAC"]
        self.base_url = f"{self.host}/portal.php"
        self.genre_id = genre_id
        self.bouquet_title = bouquet_title
        self.channels = []
        self.original_channels = []
        self.favorites = self.load_favorites()
        
        self["main_list"] = MenuList([])
        self["status"] = Label("Chargement des chaînes...")
        self["key_red"] = Label("Retour")
        self["key_green"] = Label("Recherche")
        self["key_yellow"] = Label("Favoris")
        self["key_blue"] = Label("Lecteur")
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "ok": self.playChannel,
            "green": self.showSearch,
            "yellow": self.toggleFavorite,
            "blue": self.openIntegratedPlayer,  # Nouveau: ouvrir le lecteur intégré
            "red": self.close,
            "cancel": self.close
        }, -1)
        
        self.loadChannels()

    def openIntegratedPlayer(self):
        """Ouvre le lecteur intégré avec toutes les chaînes."""
        if not self.channels:
            self["status"].setText("Aucune chaîne disponible pour le lecteur")
            return
        
        # Obtenir l'index de la chaîne actuellement sélectionnée
        current_index = self["main_list"].getSelectedIndex()
        if current_index < 0:
            current_index = 0
        
        # Ouvrir le lecteur intégré
        self.session.open(StalkerPlayer, self.server, self.channels, current_index)

    def playChannel(self):
        """Lit la chaîne sélectionnée (méthode originale conservée pour compatibilité)."""
        selected = self["main_list"].getCurrent()
        if selected:
            # Option: Demander quel lecteur utiliser
            choices = [
                ("Lecteur intégré (avec zapping)", "integrated"),
                ("Lecteur simple", "simple")
            ]
            
            def choice_callback(result):
                if result:
                    if result[1] == "integrated":
                        current_index = self["main_list"].getSelectedIndex()
                        self.session.open(StalkerPlayer, self.server, self.channels, current_index)
                    else:
                        self.playChannelSimple()
            
            from Screens.ChoiceBox import ChoiceBox
            self.session.openWithCallback(choice_callback, ChoiceBox, 
                                        title="Choisir le lecteur:", list=choices)
        else:
            self["status"].setText("Aucune chaîne sélectionnée.")

    def playChannelSimple(self):
        """Lecture simple de la chaîne (méthode originale)."""
        selected = self["main_list"].getCurrent()
        if selected:
            channel = selected[1]
            try:
                channel_name = channel.get('name', 'Unknown Name')
                channel_id = channel.get('id', 'Unknown ID')
                
                if channel_id == 'Unknown ID' or not channel_id:
                    self["status"].setText(f"ID de chaîne introuvable pour {channel_name}.")
                    return

                stream_url = f"{self.host}/live/{self.mac}/{channel_id}.ts?mac={self.mac}"
                service_ref = eServiceReference(4097, 0, stream_url)
                service_ref.setName(channel_name)
                
                result = self.session.nav.playService(service_ref)
                if result:
                    self["status"].setText(f"Lecture de {channel_name}...")
                else:
                    self["status"].setText(f"Erreur lecture {channel_name}")
                    
            except Exception as e:
                self["status"].setText(f"Erreur de lecture: {str(e)}")
                logging.error(f"Error in playChannelSimple: {str(e)}", exc_info=True)

    # ... (reste des méthodes identiques à la version précédente)
    
    def loadChannels(self):
        """Charge les chaînes depuis l'API Stalker, avec filtrage par genre si spécifié."""
        try:
            headers = {"Cookie": f"mac={self.mac}"}
            channels_data = None
            
            if self.genre_id:
                endpoints = [
                    ("get_ordered_list", f"{self.base_url}?type=itv&action=get_ordered_list&genre={self.genre_id}&force_ch_link_check=&fav=0&sortby=number&hd=0&p=0"),
                    ("get_all_channels_filtered", f"{self.base_url}?type=itv&action=get_all_channels&genre={self.genre_id}"),
                ]
            else:
                endpoints = [
                    ("get_all_channels", f"{self.base_url}?type=itv&action=get_all_channels"),
                ]
            
            for endpoint_name, url in endpoints:
                try:
                    response = requests.get(url, headers=headers, timeout=15)
                    response.raise_for_status()
                    data = response.json()
                    
                    if 'js' in data and 'data' in data['js']:
                        channels_data = data['js']['data']
                    elif 'data' in data:
                        channels_data = data['data']
                    
                    if channels_data and len(channels_data) > 0:
                        break
                        
                except Exception as e:
                    logging.error(f"Error with {endpoint_name}: {str(e)}")
                    continue

            if not channels_data:
                self["status"].setText("Aucune chaîne disponible")
                return

            all_channels = []
            for channel in channels_data:
                if isinstance(channel, dict):
                    name = channel.get('name', 'Chaîne inconnue')
                    if channel.get('id') and name:
                        all_channels.append((name, channel))

            self.channels = all_channels
            self.original_channels = self.channels[:]
            self.updateList()
            self["status"].setText(f"{len(self.channels)} chaînes chargées")
            
        except Exception as e:
            self["status"].setText(f"Erreur chargement chaînes: {str(e)}")
            logging.error(f"Error loading channels: {str(e)}", exc_info=True)

    def updateList(self):
        """Met à jour la liste des chaînes avec indication des favoris."""
        displayed_items = []
        for name, channel in self.channels:
            if channel['id'] in self.favorites:
                displayed_items.append((f"★ {name}", channel))
            else:
                displayed_items.append((name, channel))
        self["main_list"].setList(displayed_items)

    def toggleFavorite(self):
        """Ajoute ou supprime une chaîne des favoris."""
        selected = self["main_list"].getCurrent()
        if selected:
            channel_id = selected[1]['id']
            if channel_id in self.favorites:
                self.favorites.remove(channel_id)
                self["status"].setText("Supprimé des favoris")
            else:
                self.favorites.append(channel_id)
                self["status"].setText("Ajouté aux favoris")
            self.save_favorites()
            self.updateList()

    def showSearch(self):
        """Ouvre l'écran de recherche."""
        from Components.Input import Input
        self.session.openWithCallback(self.searchCallback, InputBox, 
                                    title="Rechercher une chaîne:", 
                                    text="", maxSize=False, type=Input.TEXT)

    def searchCallback(self, search_term):
        """Callback pour traiter le terme de recherche."""
        if search_term is not None:
            search_term = search_term.lower().strip()
            if search_term:
                filtered_channels = []
                for name, channel in self.original_channels:
                    if search_term in name.lower():
                        filtered_channels.append((name, channel))
                
                if filtered_channels:
                    self.channels = filtered_channels
                    self.updateList()
                    self["status"].setText(f"{len(filtered_channels)} chaînes trouvées")
                else:
                    self["status"].setText("Aucune chaîne trouvée")
            else:
                self.channels = self.original_channels[:]
                self.updateList()
                self["status"].setText(f"{len(self.channels)} chaînes")

    def load_favorites(self):
        """Charge la liste des favoris."""
        try:
            if os.path.exists(FAVORITES_PATH):
                with open(FAVORITES_PATH, 'r') as f:
                    return json.load(f)
            return []
        except Exception:
            return []

    def save_favorites(self):
        """Sauvegarde la liste des favoris."""
        try:
            with open(FAVORITES_PATH, 'w') as f:
                json.dump(self.favorites, f, indent=4)
        except Exception as e:
            logging.error(f"Error saving favorites: {str(e)}")