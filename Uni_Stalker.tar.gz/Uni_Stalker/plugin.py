# -*- coding: utf-8 -*-
"""
Uni_Stalker - Enigma2 plugin for connecting to Stalker portal servers
Author: Said MABROUR SOBHI
Version: 1.0
"""

# Gestion des imports plus robuste
import os
import sys
import json
import re
import logging
import requests
import socket
import subprocess
import psutil

# Importations Enigma2
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.InputBox import InputBox
from Components.ActionMap import ActionMap
from Components.ConfigList import ConfigListScreen
from Components.config import config, ConfigText, getConfigListEntry, ConfigSubsection
from Components.Console import Console
from Components.Label import Label
from Components.Sources.List import List
from Components.MenuList import MenuList
from enigma import eTimer, eServiceReference

# Importation de SaidClient
try:
    # Essayer l'import absolu d'abord
    from SaidClient import Said
    SAID_CLIENT_IMPORTED = True
except ImportError:
    try:
        # Essayer l'import relatif
        from .SaidClient import Said
        SAID_CLIENT_IMPORTED = True
    except ImportError:
        SAID_CLIENT_IMPORTED = False
        # Classe factice pour éviter les erreurs de compilation
        class Said:
            def __init__(self, *args, **kwargs):
                pass

# Importation de Uni_Stalker (StalkerManagerScreen)
try:
    # Essayer l'import absolu d'abord
    from Uni_Stalker import StalkerManagerScreen
    UNI_STALKER_IMPORTED = True
except ImportError:
    try:
        # Essayer l'import relatif
        from .Uni_Stalker import StalkerManagerScreen
        UNI_STALKER_IMPORTED = True
    except ImportError:
        UNI_STALKER_IMPORTED = False
        # Classe factice pour éviter les erreurs de compilation
        class StalkerManagerScreen:
            def __init__(self, session):
                pass

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='/tmp/Uni_Stalker.log'
)
logger = logging.getLogger(__name__)

# Create ConfigSubsection for plugin settings
config.plugins.Uni_Stalker = ConfigSubsection()
config.plugins.Uni_Stalker.portal = ConfigText(default="http://your-stalker-portal.com", fixed_size=False)
config.plugins.Uni_Stalker.mac = ConfigText(default="00:1A:79:00:00:00", fixed_size=False)
config.plugins.Uni_Stalker.name = ConfigText(default="My Stalker Server", fixed_size=False)

# Configuration file path - Corrigé le nom du dossier 'Servers'
CONFIG_PATH = "/usr/lib/enigma2/python/Plugins/Extensions/Uni_Stalker/Servers/Stalker.json"


class Uni_StalkerScreen(Screen, ConfigListScreen):
    """Main plugin screen for server configuration management"""
    skin = """
        <screen position="center,center" size="1200,750" title="Uni_Stalker by Said M.S for G.WOE2" backgroundColor="#8b008b">
            <widget name="config" position="150,260" size="900,200" itemHeight="55" backgroundColor="blue" scrollbarMode="showOnDemand" />
            <eLabel text="Add" position="210,650" size="180,40" font="Bold;30" halign="center" valign="center" backgroundColor="#006400" foregroundColor="white"/>
            <eLabel text="Delete" position="410,650" size="180,40" font="Bold;30" halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <eLabel text="Edit" position="610,650" size="180,40" font="Bold;30" halign="center" valign="center" backgroundColor="yellow" foregroundColor="white"/>
            <eLabel text="Portals" position="810,650" size="180,40" font="Bold;30" halign="center" valign="center" backgroundColor="blue" foregroundColor="white"/>
            <eLabel text="Uni_Stalker" position="150,70" size="900,50" font="Bold;40" halign="center" valign="center" itemHeight="55" backgroundColor="blue" foregroundColor="white"/>
            <eLabel text="Configure your Stalker Portal servers" position="150,120" size="900,30" font="Regular;30" halign="center" itemHeight="50" valign="center" backgroundColor="blue" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session):
        """Initialize the screen and configuration"""
        self.session = session
        Screen.__init__(self, session)
        self["actions"] = ActionMap(["SetupActions", "ColorActions", "OkCancelActions"], {
            "red": self.delete_server,
            "green": self.save_server,
            "yellow": self.edit_server,
            "ok": self.save_server,
            "blue": self.browse_portals,  # Le bouton bleu appelle browse_portals
            "cancel": self.exit,
        }, -2)

        # Configuration fields
        self.server_name = ConfigText(default="server", fixed_size=False)
        self.server_host = ConfigText(default="http://host.com:port/c/", fixed_size=False)
        self.server_mac = ConfigText(default="00:1A:79:AA:BB:99", fixed_size=False)

        # Initialize configuration list
        ConfigListScreen.__init__(self, [
            getConfigListEntry("Server Name", self.server_name),
            getConfigListEntry("Host", self.server_host),
            getConfigListEntry("MAC Address", self.server_mac)
        ])

        # Variable to store the current URL
        self.current_url = None
        logger.info("Uni_Stalker screen initialized")

    def save_server(self):
        """Save server configuration"""
        data = {
            "SERVER_NAME": self.server_name.value,
            "SERVER_HOST": self.server_host.value,
            "ADRESS_MAC": self.server_mac.value
        }
        try:
            self._validate_server(data)
            self._add_server(data)
            self.session.open(MessageBox, "Server added successfully!", MessageBox.TYPE_INFO, timeout=3)
            # Run the configuration script if it exists
            script_path = "/usr/lib/enigma2/python/Plugins/Extensions/Uni_Stalker/script.sh"
            if os.path.exists(script_path):
                Console().ePopen(script_path)
            else:
                logger.warning(f"Script not found: {script_path}")
        except Exception as e:
            logger.error(f"Error saving server parameters: {str(e)}")
            self.session.open(MessageBox, f"Error: {str(e)}", MessageBox.TYPE_ERROR, timeout=3)

    def _validate_server(self, data):
        """Validate server configuration data"""
        # Validate MAC address format
        if not re.match(r"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$", data["ADRESS_MAC"]):
            raise Exception("Invalid MAC address format!")
        # Validate server URL format
        if not re.match(r"^https?://[^ ]+$", data["SERVER_HOST"]):
            raise Exception("Invalid URL format!")
        # Check for duplicate servers
        if os.path.exists(CONFIG_PATH):
            with open(CONFIG_PATH, "r") as f:
                try:
                    servers = json.load(f)
                    if not isinstance(servers, list):
                        servers = []
                except json.JSONDecodeError:
                    servers = []
            for server in servers:
                if server["SERVER_NAME"] == data["SERVER_NAME"]:
                    raise Exception("A server with this name already exists!")
                if server["ADRESS_MAC"] == data["ADRESS_MAC"]:
                    raise Exception("A server with this MAC address already exists!")

    def _add_server(self, data):
        """Add a server to the configuration file"""
        try:
            if os.path.exists(CONFIG_PATH):
                with open(CONFIG_PATH, "r") as f:
                    try:
                        servers = json.load(f)
                        if not isinstance(servers, list):
                            servers = []
                    except json.JSONDecodeError:
                        servers = []
            else:
                servers = []
            servers.append(data)
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
            with open(CONFIG_PATH, "w") as f:
                json.dump(servers, f, indent=4)
        except Exception as e:
            raise Exception(f"Error adding server: {str(e)}")

    def delete_server(self):
        """Delete a server from configuration"""
        try:
            if os.path.exists(CONFIG_PATH):
                with open(CONFIG_PATH, "r") as f:
                    try:
                        servers = json.load(f)
                        if not isinstance(servers, list):
                            servers = []
                    except json.JSONDecodeError:
                        servers = []
                if servers:
                    server_list = [(f"{server['SERVER_NAME']} - {server['SERVER_HOST']} - {server['ADRESS_MAC']}", server) for server in servers]
                    self.session.openWithCallback(self.delete_server_callback, ChoiceBox, title="Choose a server to delete", list=server_list)
                else:
                    self.session.open(MessageBox, "No servers configured!", MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(MessageBox, "No servers configured!", MessageBox.TYPE_INFO, timeout=3)
        except Exception as e:
            logger.error(f"Error reading servers: {str(e)}")
            self.session.open(MessageBox, f"Error: {str(e)}", MessageBox.TYPE_ERROR, timeout=3)

    def delete_server_callback(self, result):
        """Callback when a server is selected for deletion"""
        if result:
            server = result[1]
            try:
                with open(CONFIG_PATH, "r") as f:
                    servers = json.load(f)
                servers = [s for s in servers if s["SERVER_NAME"] != server["SERVER_NAME"]]
                with open(CONFIG_PATH, "w") as f:
                    json.dump(servers, f, indent=4)
                self.session.open(MessageBox, f"Server {server['SERVER_NAME']} has been deleted.", MessageBox.TYPE_INFO, timeout=3)
            except Exception as e:
                logger.error(f"Error deleting server: {str(e)}")
                self.session.open(MessageBox, f"Error: {str(e)}", MessageBox.TYPE_ERROR, timeout=3)

    def edit_server(self):
        """Edit a server configuration"""
        try:
            if os.path.exists(CONFIG_PATH):
                with open(CONFIG_PATH, "r") as f:
                    try:
                        servers = json.load(f)
                        if not isinstance(servers, list):
                            servers = []
                    except json.JSONDecodeError:
                        servers = []
                if servers:
                    server_list = [(f"{server['SERVER_NAME']} - {server['SERVER_HOST']} - {server['ADRESS_MAC']}", server) for server in servers]
                    self.session.openWithCallback(self.edit_server_callback, ChoiceBox, title="Choose a server to edit", list=server_list)
                else:
                    self.session.open(MessageBox, "No servers configured!", MessageBox.TYPE_INFO, timeout=3)
            else:
                self.session.open(MessageBox, "No servers configured!", MessageBox.TYPE_INFO, timeout=3)
        except Exception as e:
            logger.error(f"Error reading servers: {str(e)}")
            self.session.open(MessageBox, f"Error: {str(e)}", MessageBox.TYPE_ERROR, timeout=3)

    def edit_server_callback(self, result):
        """Callback when a server is selected for editing"""
        if result:
            server = result[1]
            self.session.openWithCallback(
                lambda x: self.edit_server_field(server, x, "SERVER_NAME", server["SERVER_NAME"], "Host"),
                InputBox,
                title="Edit server name",
                text=server["SERVER_NAME"]
            )

    def edit_server_field(self, server, new_value, field, current_value, next_field=None):
        """Handle editing of a server field"""
        if new_value:
            server[field] = new_value
            if next_field == "Host":
                self.session.openWithCallback(
                    lambda x: self.edit_server_field(server, x, "SERVER_HOST", server["SERVER_HOST"], "MAC"),
                    InputBox,
                    title="Edit server host",
                    text=server["SERVER_HOST"]
                )
            elif next_field == "MAC":
                self.session.openWithCallback(
                    lambda x: self.edit_server_field(server, x, "ADRESS_MAC", server["ADRESS_MAC"], None),
                    InputBox,
                    title="Edit MAC address",
                    text=server["ADRESS_MAC"]
                )
            else:
                # Save all changes
                try:
                    with open(CONFIG_PATH, "r") as f:
                        servers = json.load(f)
                    for i, s in enumerate(servers):
                        if s["SERVER_NAME"] == current_value:
                            servers[i] = server
                            break
                    with open(CONFIG_PATH, "w") as f:
                        json.dump(servers, f, indent=4)
                    self.session.open(MessageBox, "Server updated successfully!", MessageBox.TYPE_INFO, timeout=3)
                except Exception as e:
                    logger.error(f"Error updating server: {str(e)}")
                    self.session.open(MessageBox, f"Error: {str(e)}", MessageBox.TYPE_ERROR, timeout=3)

    def browse_portals(self):
        """Ouvre directement l'interface StalkerManagerScreen"""
        if UNI_STALKER_IMPORTED:
            try:
                # Ouvrir directement l'écran StalkerManagerScreen
                self.session.open(StalkerManagerScreen)
            except Exception as e:
                logger.error(f"Error opening StalkerManagerScreen: {str(e)}")
                self.session.open(MessageBox, f"Error opening Stalker Manager: {str(e)}", MessageBox.TYPE_ERROR, timeout=5)
        else:
            self.session.open(MessageBox, "Stalker Manager module not found!", MessageBox.TYPE_ERROR, timeout=5)

    def exit(self):
        """Exit the screen"""
        self.close()


class PortalBrowserScreen(Screen):
    """Screen for browsing portal content"""
    skin = """
        <screen position="center,center" size="1000,600" title="Portal Browser" backgroundColor="#003161">
            <widget name="menu" position="50,100" size="900,400" itemHeight="40" font="Regular;28" backgroundColor="#003161" />
            <eLabel text="Back" position="100,520" size="180,40" font="Bold;30" halign="center" valign="center" backgroundColor="red" foregroundColor="white"/>
            <eLabel text="Select" position="300,520" size="180,40" font="Bold;30" halign="center" valign="center" backgroundColor="green" foregroundColor="white"/>
            <widget name="title" position="50,30" size="900,50" font="Bold;36" halign="center" valign="center" backgroundColor="#003161" foregroundColor="white"/>
        </screen>
    """

    def __init__(self, session, server):
        """Initialize the portal browser screen"""
        self.session = session
        self.server = server
        Screen.__init__(self, session)
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.select_item,
            "red": self.close,
            "green": self.select_item,
            "cancel": self.close,
        }, -2)
        self["menu"] = MenuList([])
        self["title"] = Label(f"Portal: {server['SERVER_NAME']}")
        self.client = None
        self.current_path = []
        self.categories = []
        self.channels = []
        # Initialize the client and load categories
        self.initialize_client()

    def initialize_client(self):
        try:
            logger.info(f"Initializing client for {self.server['SERVER_NAME']}")
            # Validate config
            if not all(k in self.server for k in ['SERVER_HOST', 'ADRESS_MAC']):
                raise ValueError("Invalid server configuration")
            if not SAID_CLIENT_IMPORTED:
                raise ImportError("SaidClient module not found")
            self.client = Said(self.server["SERVER_HOST"], self.server["ADRESS_MAC"])
            # Test connection
            success, msg = self.client.test_connection()
            if not success:
                raise ConnectionError(msg)
            self.load_categories()
        except ImportError as e:
            self.show_error(f"Import error: {str(e)}")
        except ValueError as e:
            self.show_error(f"Config error: {str(e)}")
        except ConnectionError as e:
            self.show_error(f"Connection failed: {str(e)}")
        except Exception as e:
            self.show_error(f"Unexpected error: {str(e)}")

    def show_error(self, message):
        self["title"].setText("Error")
        self["menu"].setList([message, "Press OK to retry", "Exit to cancel"])
        self["actions"] = ActionMap(["SetupActions", "ColorActions"], {
            "ok": self.retry_connection,
            "cancel": self.close,
            "red": self.close,
        }, -2)

    def retry_connection(self):
        self["menu"].setList(["Retrying connection..."])
        from twisted.internet import reactor
        reactor.callLater(1, self.initialize_client)  # Retry after 1 second

    def load_categories(self, callback=None):
        try:
            self["menu"].setList(["Loading categories..."])
            categories = self.client.get_categories()
            if not categories:
                raise Exception("Server returned no categories")
            self.categories = categories
            menu_items = [cat['title'] for cat in categories]
            self["menu"].setList(menu_items)
            if callback:
                callback()
        except Exception as e:
            logger.error(f"Category load error: {str(e)}")
            self.show_error(f"Failed to load categories: {str(e)}")

    def load_channels(self, category_id):
        try:
            self["menu"].setList(["Loading channels..."])
            channels = self.client.get_channels(category_id)
            if not channels:
                raise Exception("No channels in this category")
            self.channels = channels
            menu_items = [chan['name'] for chan in channels]
            self["menu"].setList(menu_items)
            self.current_path.append(("category", category_id))
        except Exception as e:
            logger.error(f"Channel load error: {str(e)}")
            self.show_error(f"Failed to load channels: {str(e)}")

    def select_item(self):
        """Handle selection of a menu item"""
        sel = self["menu"].getCurrent()
        if not sel:
            return
        if not self.current_path:  # In root (categories)
            idx = self["menu"].getSelectedIndex()
            if idx < 0 or idx >= len(self.categories):
                return
            category = self.categories[idx]
            self.load_channels(category['id'])
        else:  # In channels
            idx = self["menu"].getSelectedIndex()
            if idx < 0 or idx >= len(self.channels):
                return
            channel = self.channels[idx]
            self.play_channel(channel)

    def play_channel(self, channel):
        """Play the selected channel"""
        try:
            logger.info(f"Getting stream URL for channel {channel['name']}")
            stream_url = self.client.get_stream_url(channel['id'])
            if not stream_url:
                logger.warning("Could not get stream URL")
                self["title"].setText("Erreur de flux")
                self["menu"].setList(["Impossible d'obtenir l'URL du flux"])
                return
            logger.info(f"Stream URL: {stream_url}")
            # Ask user which player to use
            choices = [
                ("Internal player", "internal"),
                ("External player (exteplayer3)", "external")
            ]
            self.session.openWithCallback(
                lambda result: self.play_with_selected_player(result, stream_url),
                ChoiceBox,
                title=f"Play {channel['name']} with:",
                list=choices
            )
        except Exception as e:
            logger.error(f"Error getting stream URL: {str(e)}")
            self["title"].setText(f"Erreur: {str(e)}")
            self["menu"].setList(["Erreur lors de l'obtention de l'URL du flux"])

    def play_with_selected_player(self, result, url):
        """Play with the selected player type"""
        if not result:
            return
        choice = result[1]
        if choice == "internal":
            self.play_with_internal_player(url)
        elif choice == "external":
            self.play_with_exteplayer3(url)

    def play_with_internal_player(self, url):
        """Play using the internal Enigma2 player"""
        try:
            logger.info(f"Playing with internal player: {url}")
            service = eServiceReference(4097, 0, url)
            self.session.open(MoviePlayer, service)
        except Exception as e:
            logger.error(f"Error playing with internal player: {str(e)}")
            self["title"].setText(f"Erreur: {str(e)}")
            self["menu"].setList(["Erreur lors de la lecture du flux"])

    def play_with_exteplayer3(self, url):
        """Play using exteplayer3"""
        try:
            # Check if exteplayer3 is already running
            self.stop_exteplayer3()
            logger.info(f"Playing with exteplayer3: {url}")
            command = ["exteplayer3", url]
            subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception as e:
            logger.error(f"Error playing with exteplayer3: {str(e)}")
            self["title"].setText(f"Erreur: {str(e)}")
            self["menu"].setList(["Erreur lors de la lecture avec exteplayer3"])

    def stop_exteplayer3(self):
        """Stop exteplayer3 if running"""
        try:
            for proc in psutil.process_iter():
                if proc.name() == "exteplayer3":
                    logger.info("Stopping existing exteplayer3 instance")
                    proc.kill()
        except Exception as e:
            logger.error(f"Error stopping exteplayer3: {str(e)}")


class MoviePlayer(Screen):
    """Simple movie player screen for internal playback"""
    skin = """
        <screen position="center,center" size="1280,720" title="Movie Player" backgroundColor="transparent" flags="wfNoBorder">
        </screen>
    """

    def __init__(self, session, service):
        """Initialize the movie player"""
        Screen.__init__(self, session)
        self["actions"] = ActionMap(["OkCancelActions", "MoviePlayerActions"], {
            "ok": self.ok,
            "cancel": self.close,
            "playpause": self.playpause,
            "seekFwd": self.seek_forward,
            "seekBack": self.seek_backward,
        }, -2)
        self.service = service
        self.session.nav.playService(service)
        self.paused = False  # Ajout de l'attribut pour suivre l'état de pause

    def ok(self):
        """OK button handler"""
        pass

    def playpause(self):
        """Toggle play/pause"""
        service = self.session.nav.getCurrentService()
        if service:
            pausable = service.pause()
            if pausable:
                if self.paused:
                    pausable.unpause()
                    self.paused = False
                else:
                    pausable.pause()
                    self.paused = True

    def seek_forward(self):
        """Seek forward"""
        seekable = self.get_seekable()
        if seekable:
            seekable.seekRelative(1, 10 * 90000)  # 10 seconds forward

    def seek_backward(self):
        """Seek backward"""
        seekable = self.get_seekable()
        if seekable:
            seekable.seekRelative(1, -10 * 90000)  # 10 seconds backward

    def close(self):
        """Close the player"""
        self.session.nav.stopService()
        Screen.close(self)

    def get_seekable(self):
        """Get the seekable interface"""
        service = self.session.nav.getCurrentService()
        if service:
            return service.seek()
        return None


def main(session, **kwargs):
    """Main function to open the plugin"""
    session.open(Uni_StalkerScreen)


def Plugins(**kwargs):
    """Plugin descriptor for Enigma2"""
    return [
        PluginDescriptor(
            name="Uni_Stalker",
            description="Stalker Portal Client by Said M.S",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",  # Assurez-vous que icon.png existe
            fnc=main
        ),
        PluginDescriptor(
            name="Uni_Stalker",
            description="Stalker Portal Client",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        )
    ]




